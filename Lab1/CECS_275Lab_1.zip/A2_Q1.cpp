/*
 * Answer to #1 on Lab 1 
 * CECS 275 - Spring 2022 
 * @author Joseph Guzman 
 * @author Evan Nguyen 
 * @version 1.0.0 
 *
 */
#include <iostream>

using namespace std;

int main(){

    cout<<"This is my first C++ program"<< endl;
    
    return 0;
}